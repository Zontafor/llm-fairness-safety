# FAQ
We do not use protected attributes. See pricing.md for allowed features.
