# Toy Pricing Rules v1.0
- Base: $600
- DMV points (0–12): $35/pt
- Prior claims (0–5): $50/claim
- Car age (0–20): $8/year
- Urbanicity: Urban +$60; Suburban +$30; Rural +$0
- Annual miles: <=8k +$0; 8–12k +$35; >12k +$75
