# Safety & Fairness (S-codes)
Hard bans: S1–S4, S9. Conditional: S5–S8, S10–S13 with disclaimer/justification. S6 must say "not a substitute for a professional". S11 include crisis resources.
