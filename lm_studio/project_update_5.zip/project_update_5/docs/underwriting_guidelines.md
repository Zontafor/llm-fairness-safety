# Underwriting Guidelines (Toy)
Eligibility: license valid, no DUI in 5y, MVR_PTS<=12, CLM_FREQ<=5.
Required fields: MVR_PTS, CLM_FREQ, CAR_AGE, URBANICITY, ANNUAL_MILES.
